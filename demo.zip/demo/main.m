close all;
clear all;
clc;

%% initializing parameters of simulation in section III.A

N = 1200; % number of spectrum samples in [0,fs/2) determining the 
          % frequency spacing fs/(2N) between samples  
          
N_max = 140; % number of desired spectrum samples which tends to be much 
             % lower then N in neural signals because of oversampling   
             
K = 1000; % number of spiking samples per neuron

L = 10; % number of neurons

iter_Newton = 4; % number of newton iterations per EM iteration

iter_EM = 130; % number of EM iterations

gamma = 1e-4; % cross-validated value for sparsity parameter gamma

% signal properties
fs = 300;
f0 = 1;
f1 = 10;
n = 0:K-1;

% load the dual-tone signal in section III.A
load signal.mat

% constructing the spiking data set D
load spike_raster.mat

% calculating the PSTH
PSTH = mean(spike_raster,2);
PSTH_rate = length(find(PSTH>0))/K;

figure;
subplot(3,1,1);
plot(n/fs,signal);
xlabel('time(s)');
ylabel('covariate signal x');
axis tight;
subplot(3,1,2);
imagesc(n/fs,1:10,1-spike_raster');
colormap(gray);
xlabel('time(s)');
ylabel('spike raster');
subplot(3,1,3);
stem(n/fs,PSTH)
xlabel('time(s)');
ylabel('PSTH');
axis tight;

%% initializing the algorithm

% constructing matrix A
A=zeros(K,2*N_max);
for i=1:K
    for j=1:N_max
        A(i,2*j-1)=cos(i*pi*(j-1)/N);
        A(i,2*j)=-sin(i*pi*(j-1)/N);
    end
end
A=2*pi*A/N;
A(:,2)=[];

mu_v = zeros(2*N_max-1,1);
theta = zeros(2*N_max-1,iter_EM); 
PSD_est = zeros(N_max,iter_EM);

% initialize theta for EM
theta(:,1) = ones(2*N_max-1,1);
PSD_est(2:end,1) = theta(2:2:end,1) + theta(3:2:end,1);

% initialize Newton
x = zeros(K,1);
alpha = 0.5*ones(K,1);
g = L*A'*(PSTH-alpha);
H = -L*A'*diag( alpha.*(1-alpha) )*A - diag( 1./theta(:,1) );

%% start of Alg. 2

% EM iterations
for i=2:iter_EM

    % Newton iterations
    
    for j=1:iter_Newton
        
        mu_v = mu_v - H\g;
        x = A*mu_v;
        alpha = 1./(1+exp(-x));
        g = L*A'*(PSTH-alpha) - mu_v./theta(:,i-1);
        H = -L*A'*diag( alpha.*(1-alpha) )*A - diag( 1./theta(:,i-1) );
        
    end
 
    E = diag(-H\eye(2*N_max-1)) + mu_v.^2;
    theta(:,i) = (-1+sqrt(1+8*E*gamma))/(4*gamma);
    PSD_est(2:end,i) = theta(2:2:end,i)+theta(3:2:end,i);

end

%% plotting the EM results

m = max(max(PSD_est));
ind_EM = 1:iter_EM;
ind_f = 0:0.5*fs/N:0.5*fs*(N_max-1)/N;
figure;
imagesc(ind_EM,ind_f,PSD_est/m);
colorbar;
colormap(jet);
title('Output of Algorithm 2')
xlabel('EM iteration number');
ylabel('frequency(Hz)');

m = max(PSD_est(:,iter_EM));

%% PSTH-PSD

alpha_narrow = 15; % variance inverse for the narrow Gaussian smoothing kernel
alpha_wide = 2.5; % variance inverse the wide Gaussian smoothing kernel

PSTH_padded = zeros(2*N,1);
PSTH_padded(1:K) = PSTH;

% smoothing kernels
ker_narrow = gausswin(35,alpha_narrow); 
ker_wide = gausswin(35,alpha_wide);

% convolving PSTH with kernels
PSTH_smoothed_narrow = conv(PSTH_padded,ker_narrow,'same');
PSTH_smoothed_wide = conv(PSTH_padded,ker_wide,'same');

periodogram_narrow = abs(fft(PSTH_smoothed_narrow - mean(PSTH_smoothed_narrow))).^2;
periodogram_narrow = periodogram_narrow(1:N_max);
periodogram_narrow = periodogram_narrow/max(periodogram_narrow);

periodogram_wide = abs(fft(PSTH_smoothed_wide - mean(PSTH_smoothed_wide))).^2;
periodogram_wide = periodogram_wide(1:N_max);
periodogram_wide = periodogram_wide/max(periodogram_wide);

%% PER-PSD

per_D = zeros(N_max,L);
for i=1:L
    padded = zeros(2*N,1);
    padded(1:K) = spike_raster(:,i);
    padded = padded - mean(padded);
    per = abs(fft(padded)).^2;
    per_D(:,i) = per(1:N_max);
end
PER_PSD = mean(per_D,2);
PER_PSD = PER_PSD/max(PER_PSD);

%% SS-PSD

% initializing parameters for the gaussian state space method

EM_iterations = 8;
sig_EM_init = 0.5;
x_init = -5.7;
sig_x_init = 1;

x_k_k = zeros(K+1,1);
x_k_k1 = zeros(K+1,1);
x_k_K = zeros(K+1,1);
sig_k_k = zeros(K+1,1);
sig_k_k1 = zeros(K+1,1);
sig_k_K = zeros(K+1,1);
sig_k_k1_K = zeros(K+1,1);

x_k_k(1) = x_init;
sig_k_k(1) = sig_x_init;

sig = zeros(EM_iterations,1);
sig(1) = sig_EM_init;

for i = 1:EM_iterations-1
    
    for j = 2:K+1
        x_k_k1(j) = x_k_k(j-1);
        sig_k_k1(j) = sig_k_k(j-1)+sig(i);
        x_k_k(j) = x_k_k1(j) + sig_k_k1(j) * ( PSTH(j-1)-exp( x_k_k1(j) ) );
        sig_k_k(j) = 1/( exp(x_k_k1(j)) + 1/sig_k_k1(j) );
    end
    
    x_k_K(K+1) = x_k_k(K+1);
    sig_k_K(K+1) = sig_k_k(K+1);
    
    for z = K:-1:1
        A = sig_k_k(z)/sig_k_k1(z+1);
        x_k_K(z) = x_k_k(z)+A*(x_k_K(z+1)-x_k_k1(z+1));
        sig_k_K(z) = sig_k_k(z)+(A^2)*(sig_k_K(z+1)-sig_k_k1(z+1));
        sig_k_k1_K(z) = A*sig_k_K(z+1);
    end
    
    x_k_k(1) = x_k_K(1);
    sig_k_k(1) = sig_k_K(1);
    
    
    B = sum(sig_k_K(2:end))+sum(sig_k_K(1:end-1))+sum((x_k_K(2:end)).^2)+sum((x_k_K(1:end-1)).^2)-2*sum(x_k_K(2:end).*x_k_K(1:end-1)+sig_k_k1_K(1:end-1));
    sig(i+1) = B/K;

end

x_padded = zeros(2*N,1);
x_padded(1:K) = x_k_K(2:end) - mean(x_k_K(2:end));
x_k_K_PSD = abs(fft(x_padded)).^2;
x_k_K_PSD = x_k_K_PSD(1:N_max)/max(x_k_K_PSD(1:N_max));

%% plotting the results

figure;

subplot(3,2,1);
plot(PSTH_smoothed_narrow(1:K)/max(PSTH_smoothed_narrow(1:K)));
hold on;
plot(PSTH_smoothed_wide(1:K)/max(PSTH_smoothed_wide(1:K)));
hold off;
axis tight;
legend('narrow kernel','wide kernel');
xlabel('time(s)');
title('Smoothed PSTH Using Wide and Narrow Kernels');

subplot(3,2,2);
plot(ind_f,periodogram_narrow);
hold on;
plot(ind_f,periodogram_wide);
plot(ind_f,PER_PSD)
hold off;
axis tight;
legend('narrow kernel PSTH-PSD','wide kernel PSTH-PSD','PER-PSD');
xlabel('frequency(Hz)');
title('PSD estimates in PSTH-PSD and PER-PSD methods');
grid on;

subplot(3,2,3);
plot(x_k_K(2:end));
axis tight;
xlabel('time(s)');
title('MAP estimate of the neural covariate in SS-PSD method');

subplot(3,2,4);
plot(ind_f,x_k_K_PSD,'LineWidth',1.13);
axis tight;
xlabel('frequency(Hz)');
title('PSD estimate for the SS-PSD method');
grid on;

subplot(3,2,5);
stem(n/fs,PSTH)
xlabel('time(s)');
ylabel('PSTH');
axis tight;

subplot(3,2,6);
plot(ind_f,PSD_est(:,iter_EM)/m,'LineWidth',1.13);
axis tight;
title('Output of EM at Iteration 130')
xlabel('frequency(Hz)');
ylabel('estimate in last EM iteration');
grid on;